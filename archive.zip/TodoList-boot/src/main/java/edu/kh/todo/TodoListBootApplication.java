package edu.kh.todo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoListBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoListBootApplication.class, args);
	}

}
