package edu.kh.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoProject2Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoProject2Application.class, args);
		
	}

}
